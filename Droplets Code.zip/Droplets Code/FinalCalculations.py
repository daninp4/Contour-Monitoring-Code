import cv2
import numpy as np
import matplotlib.pyplot as plt
import operator # for sorting and comparing
import pyefd
import os
import time
import h5py
import re
import subprocess
import shutil
import warnings

from scipy.optimize import curve_fit
from scipy.optimize import OptimizeWarning
from scipy.ndimage import gaussian_filter1d

time_equivalence = 30.03 #µs/s


def save_contour_frames(h5_file_path, output_folder):
    # Initial variables (to be filled with the video name and contour name)
    video_name = 'Video_1'  # Complete with the video name
    contour_name = 'Contour_F0030_1'  # Complete with the contour name

    # Create the output folder combining the video and contour names
    output_video_folder = os.path.join(output_folder, f"{video_name}_{contour_name}")

     # Check if the folder already exists
    if os.path.exists(output_video_folder):
        return  # Exit the function if the folder exists

    os.makedirs(output_video_folder, exist_ok=True)

    # Open the h5 file
    with h5py.File(h5_file_path, 'r') as file:
        # Access the folder for the specific video
        video_folder = file.get(video_name)
        if video_folder is None:
            raise ValueError(f"Video {video_name} not found in the HDF5 file.")
        
        # Initialize the frame counter
        frame_counter = 1
        
        # Loop through all the frame folders
        for frame_folder_name in video_folder:
            # Check for folders that follow the format "Dataset: Frame XXXX Time Y.YYs"
            if frame_folder_name.startswith("Dataset: Frame"):
                frame_folder = video_folder[frame_folder_name]
                frame_number = frame_folder_name.split("Frame")[1].strip().split()[0]
                
                # Check if the specific contour is present
                contour_matrix_name = f"{contour_name}"
                contour_matrix = frame_folder.get(contour_matrix_name)
                
                if contour_matrix is not None:
                    # Extract the contour coordinates
                    contour_data = contour_matrix[...]
                    
                    # Create a blank image
                    height, width = 1536, 1818  # Image size (adjust as necessary)
                    contour_image = np.ones((height, width), dtype=np.uint8) * 255  # White background

                    # Create points using the first and second columns for x and y coordinates
                    contour_points = []
                    for i in range(10000):
                        x = contour_data[0, i]  # x is in the first column
                        y = contour_data[1, i]  # y is in the second column
                        
                        # Eliminate points with coordinates [0, 0]
                        if x != 0 or y != 0:
                            contour_points.append([x, y])

                    # Convert the points to the required format for cv2.polylines
                    contour_points = np.array(contour_points, dtype=np.int32).reshape((-1, 1, 2))

                    # Draw the contour on the blank image
                    cv2.polylines(contour_image, [contour_points], isClosed=True, color=0, thickness=2)  # Black contour
                    
                    # Save the image as PNG
                    frame_image_name = f"frame_{frame_number}_{frame_counter:04d}.png"
                    frame_image_path = os.path.join(output_video_folder, frame_image_name)
                    cv2.imwrite(frame_image_path, contour_image)
                    
                    # Increment the frame counter
                    frame_counter += 1



def create_videos_for_specific_contour(input_path, output_path):
    try:
        # Validate paths
        if not os.path.exists(input_path):
            raise FileNotFoundError(f"Input path does not exist: {input_path}")
        
        # Create the output directory if it doesn't exist
        if not os.path.exists(output_path):
            os.makedirs(output_path)

        # Ensure there are images in the folder
        images = [img for img in os.listdir(input_path) if img.endswith(('.png'))]
        if not images:
            return

        # Sort images by frame number
        images.sort(key=lambda x: int(x.split("_")[-1].split(".")[0].lstrip('0') or '0'))

        # Define the name of the output video with .mkv extension
        video_name = f"Video_specific_contour.mkv"  # Change to .mkv
        video_output_path = os.path.join(output_path, video_name)  # Directly save to output_path

        # Generate a temporary text file with paths to images for ffmpeg
        temp_file = os.path.normpath(os.path.join(input_path, "images.txt"))
        with open(temp_file, "w") as file:
            for img in images:
                file.write(f"file '{os.path.join(input_path, img)}'\n")

        # Use ffmpeg to create the video with the correct frame rate handling
        command = [
            "ffmpeg",
            "-y",  # Overwrite output file if it exists
            "-f", "concat",  # Use concatenation mode
            "-safe", "0",  # Disable safe paths check
            "-r", "30",  # Hardcoded frame rate of 30
            "-i", temp_file,  # Input file with image paths
            "-fps_mode", "passthrough",  # Handle frame rate properly
            "-pix_fmt", "yuv420p",  # Format for video
            video_output_path  # Output video path
            ]

        # Suppress the output and errors from ffmpeg
        subprocess.run(command, check=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE)

        # Remove the temporary file
        os.remove(temp_file)

    except Exception as e:
        print(f"An error occurred: {e}")



def get_centroid_trajectory(h5_file_path, output_folder_path, microns_per_pixel):
    video_name = 'Video_1'
    contour_name = 'Contour_F0030_1'

    with h5py.File(h5_file_path, 'r') as file:
        video_folder = file.get(video_name)
        if video_folder is None:
            raise ValueError(f"Video {video_name} not found in the HDF5 file.")

        times = []
        centroids_x = []
        centroids_y = []

        for frame_folder_name in video_folder:
            match = re.search(r"Frame\s+(\d+)\s+Time\s+([\d.]+)s", frame_folder_name)
            if match:
                frame_time = float(match.group(2))
                
                frame_folder = video_folder[frame_folder_name]
                attributes_matrix_name = f"{contour_name}_Attributes"
                attributes_matrix = frame_folder.get(attributes_matrix_name)
                
                if attributes_matrix is not None:
                    attributes_data = attributes_matrix[...]
                    if attributes_data.shape[0] >= 4:
                        centroid_x = attributes_data[2] * microns_per_pixel  # Convert to micrometers
                        centroid_y = attributes_data[3] * microns_per_pixel  # Convert to micrometers
                        
                        times.append(frame_time)
                        centroids_x.append(centroid_x)
                        centroids_y.append(centroid_y)

        sorted_indices = np.argsort(times)
        times = np.array(times)[sorted_indices]
        times = times * time_equivalence
        centroids_x = np.array(centroids_x)[sorted_indices]
        centroids_y = np.array(centroids_y)[sorted_indices]

        def trajectory(t, a, b, c, d, e, f):
            x = a * t**2 + b * t + c
            y = d * t**2 + e * t + f
            return np.concatenate([x, y])

        try:
            with warnings.catch_warnings():
                warnings.simplefilter("error", OptimizeWarning)
                popt, _ = curve_fit(trajectory, times, np.hstack((centroids_x, centroids_y)))
                a, b, c, d, e, f = popt
                equation = f"x(t) = {a:.5f} * t^2 + {b:.5f} * t + {c:.5f}, y(t) = {d:.6f} * t^2 + {e:.5f} * t + {f:.5f}"
                fit_type = "quadratic"
        except (RuntimeError, Warning):
            def linear_trajectory(t, m_x, c_x, m_y, c_y):
                x = m_x * t + c_x
                y = m_y * t + c_y
                return np.concatenate([x, y])
            popt, _ = curve_fit(linear_trajectory, times, np.hstack((centroids_x, centroids_y)))
            m_x, c_x, m_y, c_y = popt
            equation = f"x(t) = {m_x:.5f} * t + {c_x:.5f}, y(t) = {m_y:.5f} * t + {c_y:.5f}"
            fit_type = "linear"

        def y_as_function_of_x(x, p, q, r):
            return p * x**2 + q * x + r

        try:
            popt_yx, _ = curve_fit(y_as_function_of_x, centroids_x, centroids_y)
            p, q, r = popt_yx
            equation_yx = f"y(x) = {p:.5f} * x^2 + {q:.5f} * x + {r:.5f}"
            fit_type_yx = "quadratic"
        except (RuntimeError, Warning):
            def linear_yx(x, m, c):
                return m * x + c
            popt_yx, _ = curve_fit(linear_yx, centroids_x, centroids_y)
            m, c = popt_yx
            equation_yx = f"y(x) = {m:.5f} * x + {c:.5f}"
            fit_type_yx = "linear"

        print(f"The functions describing the centroid trajectory are: {equation} ({fit_type})")
        print(f"The equation describing the centroid trajectory in terms of x is: {equation_yx} ({fit_type_yx})")

        image = np.ones((1536, 1818), dtype=np.uint8) * 255

        # Plot for x(t) using the fitted equation
        plt.figure(figsize=(18, 15)) 
        plt.imshow(image, cmap='gray', extent=[min(times), max(times), min(centroids_x), max(centroids_x)])

        # Compute the fitted trajectory for x(t)
        if fit_type == "quadratic":
            xt_values = a * np.array(times)**2 + b * np.array(times) + c
        else:
            xt_values = m_x * np.array(times) + c_x

        plt.plot(times, xt_values, color='red', linewidth=6)  # Use the fitted equation
        plt.title('x(t) equation', fontsize=32, color='black')
        plt.xlabel('Time [µs]', fontsize=23, color='black')
        plt.ylabel('X coordinates [µm]', fontsize=23, color='black')
        plt.tick_params(axis='both', which='major', labelsize=18)
        plt.xlim(min(times), max(times))
        plt.gca().set_aspect(abs(max(times) - min(times)) / abs(max(centroids_x) - min(centroids_x)))
        plt.savefig(os.path.join(output_folder_path, "x_t.png"))
        plt.close()

        # Plot for y(t) using the fitted equation
        plt.figure(figsize=(18, 15))
        plt.imshow(image, cmap='gray', extent=[min(times), max(times), min(centroids_y), max(centroids_y)])

        # Compute the fitted trajectory for y(t)
        if fit_type == "quadratic":
            yt_values = d * np.array(times)**2 + e* np.array(times) + f
        else:
            yt_values = m_y * np.array(times) + c_y

        plt.plot(times, yt_values, color='red', linewidth=6)  # Use the fitted equation
        plt.title('y(t) equation', fontsize=32, color='black')
        plt.xlabel('Time [µs]', fontsize=23, color='black')
        plt.ylabel('Y coordinates [µm]', fontsize=23, color='black')
        plt.tick_params(axis='both', which='major', labelsize=18)
        plt.xlim(min(times), max(times))
        plt.gca().set_aspect(abs(max(times) - min(times)) / abs(max(centroids_y) - min(centroids_y)))
        plt.savefig(os.path.join(output_folder_path, "y_t.png"))
        plt.close()


        # Plot for y(x) - This will plot the quadratic or linear fit for y(x)
        if fit_type_yx == "quadratic":
            yx_values = p * centroids_x**2 + q * centroids_x + r  # Quadratic equation for y(x)
        else:
            yx_values = m * centroids_x + c  # Linear equation for y(x)
        cap_x = max(centroids_x) + 100
        cap_y = max(yx_values) + 100
        plt.figure(figsize=(18, 15))  # Adjust the figure size to match the image aspect ratio
        plt.imshow(image, cmap='gray', extent=[0, cap_x, 0, cap_y])  # Show the white image
        plt.plot(centroids_x, yx_values, color='red', linewidth=3)  # Plot the trajectory for y(x)
        plt.title('y(x) equation', fontsize=32, color='black')  # Title with units
        plt.xlabel('X coordinates [µm]', fontsize=23, color='black')  # Label with units
        plt.ylabel('Y coordinates [µm]', fontsize=23, color='black')  # Label with units
        plt.tick_params(axis='both', which='major', labelsize=18)
        plt.gca().set_facecolor('black')  # Set background to black
        plt.savefig(os.path.join(output_folder_path, "y_x.png"))
        plt.close()



def plot_centroid_points(h5_file_path, output_folder_path, microns_per_pixel):
    # Initial variables (to be filled with the video name and contour name)
    video_name = 'Video_1'  # Complete with the video name
    contour_name = 'Contour_F0030_1'  # Complete with the contour name

    # Open the HDF5 file
    with h5py.File(h5_file_path, 'r') as file:
        # Access the folder for the specific video
        video_folder = file.get(video_name)
        if video_folder is None:
            raise ValueError(f"Video {video_name} not found in the HDF5 file.")
        
        # Initialize lists to store centroid coordinates
        centroids_x = []
        centroids_y = []
        
        # Loop through all the frame folders
        for frame_folder_name in video_folder:
            # Check for folders that follow the format "Dataset: Frame XXXX Time X.XXs"
            if frame_folder_name.startswith("Dataset: Frame"):
                frame_folder = video_folder[frame_folder_name]
                
                # Build the name of the attributes matrix
                attributes_matrix_name = f"{contour_name}_Attributes"
                attributes_matrix = frame_folder.get(attributes_matrix_name)
                
                if attributes_matrix is not None:
                    # Extract the data from the attributes matrix
                    attributes_data = attributes_matrix[...]
                    
                    if attributes_data.shape[0] >= 4:
                        # Extract the centroid coordinates
                        centroid_x = attributes_data[2] * microns_per_pixel  # Third value
                        centroid_y = attributes_data[3] * microns_per_pixel # Fourth value
                        
                        # Store the centroid coordinates
                        centroids_x.append(centroid_x)
                        centroids_y.append(centroid_y)

        # Convert lists to numpy arrays
        centroids_x = np.array(centroids_x)
        centroids_y = np.array(centroids_y)

        # Create a blank image of the specified size (1536x1818)
        image = np.ones((1536, 1818), dtype=np.uint8) * 255  # White background

        # Plot all centroid points
        cap_x = max(centroids_x) + 300
        cap_y = max(centroids_y) + 200
        plt.figure(figsize=(18, 15))  # Adjust the figure size to match the image aspect ratio
        plt.imshow(image, cmap='gray', extent=[0, cap_x, 0, cap_y])  # Show the white image
        plt.scatter(centroids_x, centroids_y, c='red', marker='o', label='Centroid Points', s=5)

        # Add labels and title
        plt.title('Centroid Points', fontsize=32)
        plt.xlabel('X coordinates [µm]', fontsize=23)
        plt.ylabel('Y coordinates [µm]', fontsize=23)
        plt.tick_params(axis='both', which='major', labelsize=18)

        # Ensure the output directory exists
        if not os.path.exists(output_folder_path):
            os.makedirs(output_folder_path)
        
        # Define the output image path
        output_image_path = os.path.join(output_folder_path, "Centroid_Trajectory.png")

        # Save the image to the specified path
        plt.savefig(output_image_path)
        plt.close()  # Close the figure to free memory



def plot_contours(h5_file_path, output_folder_path, microns_per_pixel):
    # Initial variables (to be filled with the video name and contour name)
    video_name = 'Video_1'  # Complete with the video name
    contour_name = 'Contour_F0030_1'  # Complete with the contour name

    # Open the HDF5 file
    with h5py.File(h5_file_path, 'r') as file:
        # Access the folder for the specific video
        video_folder = file.get(video_name)
        if video_folder is None:
            raise ValueError(f"Video {video_name} not found in the HDF5 file.")

        # Create a blank image of the specified size (1536x1818)
        image = np.ones((1536, 1818), dtype=np.uint8) * 255  # White background

        # Lists to store all valid contour points
        all_x = []
        all_y = []

        # Loop through all the frame folders
        for frame_folder_name in video_folder:
            # Check for folders that follow the format "Dataset: Frame XXXX Time X.XXs"
            if frame_folder_name.startswith("Dataset: Frame"):
                frame_folder = video_folder[frame_folder_name]
                
                # Access the contour matrix (without "_Attributes")
                contour_matrix = frame_folder.get(contour_name)
                
                if contour_matrix is not None:
                    # Extract contour points
                    contour_data = contour_matrix[...]
                    
                    if contour_data.shape[0] == 2:  # Ensure it has x and y coordinates
                        contour_data = contour_data.T  # Transpose to (N,2) format
                    
                    # Separate X and Y coordinates
                    contour_x = contour_data[:, 0]
                    contour_y = contour_data[:, 1]

                    # Filter out points (0,0)
                    valid_points = ~((contour_x == 0) & (contour_y == 0))
                    
                    # Convert to microns and store the valid points
                    all_x.extend(contour_x[valid_points] * microns_per_pixel)
                    all_y.extend(contour_y[valid_points] * microns_per_pixel)
        
        # Create figure
        plt.figure(figsize=(18, 15))  # Adjust the figure size to match the image aspect ratio
        
        if all_x and all_y:  # Ensure there are points to plot
            cap_x = max(all_x) + 300
            cap_y = max(all_y) + 200
            plt.imshow(image, cmap='gray', extent=[0, cap_x, 0, cap_y])  # Show the white image
            plt.plot(all_x, all_y, color='red', linewidth=1)
        
        # Add labels and title
        plt.title('Contours of the Selected Object', fontsize=32)
        plt.xlabel('X coordinates [µm]', fontsize=23)
        plt.ylabel('Y coordinates [µm]', fontsize=23)
        plt.tick_params(axis='both', which='major', labelsize=18)

        # Ensure the output directory exists
        if not os.path.exists(output_folder_path):
            os.makedirs(output_folder_path)

        # Define the output image path
        output_image_path = os.path.join(output_folder_path, "AllContoursInSingleFrame.png")

        # Save the image to the specified path
        plt.savefig(output_image_path)
        plt.close()  # Close the figure to free memory




def plot_centroid_and_yx(h5_file_path, output_folder_path, microns_per_pixel):
    video_name = 'Video_1'
    contour_name = 'Contour_F0030_1'

    with h5py.File(h5_file_path, 'r') as file:
        video_folder = file.get(video_name)
        if video_folder is None:
            raise ValueError(f"Video {video_name} not found in the HDF5 file.")

        times = []
        centroids_x = []
        centroids_y = []

        for frame_folder_name in video_folder:
            match = re.search(r"Frame\s+(\d+)\s+Time\s+([\d.]+)s", frame_folder_name)
            if match:
                frame_time = float(match.group(2))
                
                frame_folder = video_folder[frame_folder_name]
                attributes_matrix_name = f"{contour_name}_Attributes"
                attributes_matrix = frame_folder.get(attributes_matrix_name)
                
                if attributes_matrix is not None:
                    attributes_data = attributes_matrix[...]
                    if attributes_data.shape[0] >= 4:
                        centroid_x = attributes_data[2] * microns_per_pixel  # Convert to micrometers
                        centroid_y = attributes_data[3] * microns_per_pixel  # Convert to micrometers
                        
                        times.append(frame_time)
                        centroids_x.append(centroid_x)
                        centroids_y.append(centroid_y)

        sorted_indices = np.argsort(times)
        times = np.array(times)[sorted_indices]
        times = times * time_equivalence
        centroids_x = np.array(centroids_x)[sorted_indices]
        centroids_y = np.array(centroids_y)[sorted_indices]

        def trajectory(t, a, b, c, d, e, f):
            x = a * t**2 + b * t + c
            y = d * t**2 + e * t + f
            return np.concatenate([x, y])

        try:
            with warnings.catch_warnings():
                warnings.simplefilter("error", OptimizeWarning)
                popt, _ = curve_fit(trajectory, times, np.hstack((centroids_x, centroids_y)))
                a, b, c, d, e, f = popt
                equation = f"x(t) = {a:.5f} * t^2 + {b:.5f} * t + {c:.5f}, y(t) = {d:.5f} * t^2 + {e:.5f} * t + {f:.5f}"
                fit_type = "quadratic"
        except (RuntimeError, Warning):
            def linear_trajectory(t, m_x, c_x, m_y, c_y):
                x = m_x * t + c_x
                y = m_y * t + c_y
                return np.concatenate([x, y])
            popt, _ = curve_fit(linear_trajectory, times, np.hstack((centroids_x, centroids_y)))
            m_x, c_x, m_y, c_y = popt
            equation = f"x(t) = {m_x:.5f} * t + {c_x:.5f}, y(t) = {m_y:.5f} * t + {c_y:.5f}"
            fit_type = "linear"

        def y_as_function_of_x(x, p, q, r):
            return p * x**2 + q * x + r

        try:
            popt_yx, _ = curve_fit(y_as_function_of_x, centroids_x, centroids_y)
            p, q, r = popt_yx
            equation_yx = f"y(x) = {p:.5f} * x^2 + {q:.5f} * x + {r:.5f}"
            fit_type_yx = "quadratic"
        except (RuntimeError, Warning):
            def linear_yx(x, m, c):
                return m * x + c
            popt_yx, _ = curve_fit(linear_yx, centroids_x, centroids_y)
            m, c = popt_yx
            equation_yx = f"y(x) = {m:.5f} * x + {c:.5f}"
            fit_type_yx = "linear"

        # Extend the x range by adding 250 more pixels
        extended_x = np.linspace(min(centroids_x), max(centroids_x) + 250, 1000)

        # Calculate the corresponding y values using the fitted equation
        extended_y = p * extended_x**2 + q * extended_x + r  # Use the quadratic fit for y(x)

        # Create a blank image of the specified size (1536x1818)
        image = np.ones((1536, 1818), dtype=np.uint8) * 255  # White background

        # Plot all centroid points
        cap_x = max(centroids_x) + 300
        cap_y = max(centroids_y) + 200
        plt.figure(figsize=(18, 15))  # Adjust the figure size to match the image aspect ratio
        plt.imshow(image, cmap='gray',  extent=[0, cap_x, 0, cap_y])  # Show the white image
        plt.scatter(centroids_x, centroids_y, c='red', marker='o', label='Centroid Points', s=5)

        # Plot y(x) equation in white
        if fit_type_yx == "quadratic":
            yx_values = p * extended_x**2 + q * extended_x + r  # Quadratic equation for y(x)
        else:
            yx_values = m * extended_x + c  # Linear equation for y(x)
        plt.plot(extended_x, yx_values, color='white', linewidth=2, label=f'y(x) = {equation_yx}')

        # Add labels and title
        plt.title(f'Centroid Points and y(x) equation', fontsize=32)
        plt.xlabel('X coordinates [µm]', fontsize=23)
        plt.ylabel('Y coordinates [µm]', fontsize=23)
        plt.tick_params(axis='both', which='major', labelsize=18)

        # Ensure the output directory exists
        if not os.path.exists(output_folder_path):
            os.makedirs(output_folder_path)
        
        # Define the output image path
        output_image_path = os.path.join(output_folder_path, "Centroid_and_yx.png")

        # Save the image to the specified path
        plt.savefig(output_image_path)
        plt.close()  # Close the figure to free memory



def compute_heading(h5_file_path, output_folder_path, microns_per_pixel):

    video_name = 'Video_1'
    contour_name = 'Contour_F0030_1'
    target_time_original = 9.4  #seconds in the video

    # Open HDF5 file and extract centroid data
    with h5py.File(h5_file_path, 'r') as file:
        video_folder = file.get(video_name)
        if video_folder is None:
            raise ValueError(f"Video {video_name} not found in the HDF5 file.")
        
        times, centroids_x, centroids_y = [], [], []

        #Target time conversion
        target_time = target_time_original * time_equivalence
        
        for frame_folder_name in video_folder:
            match = re.search(r"Frame\s+(\d+)\s+Time\s+([\d.]+)s", frame_folder_name)
            if match:
                frame_time = float(match.group(2))
                
                frame_folder = video_folder[frame_folder_name]
                attributes_matrix_name = f"{contour_name}_Attributes"
                attributes_matrix = frame_folder.get(attributes_matrix_name)
                
                if attributes_matrix is not None:
                    attributes_data = attributes_matrix[...]
                    if attributes_data.shape[0] >= 4:
                        centroids_x.append(attributes_data[2])
                        centroids_y.append(attributes_data[3])
                        times.append(frame_time)
        
        # Sort data by time
        sorted_indices = np.argsort(times)
        times = np.array(times)[sorted_indices]
        times = times * time_equivalence
        centroids_x = np.array(centroids_x)[sorted_indices]
        centroids_y = np.array(centroids_y)[sorted_indices]
        centroids_x = centroids_x * microns_per_pixel
        centroids_y = centroids_y * microns_per_pixel
        
        # Select the data to plot based on target_time
        if target_time <= times[-1]:
            valid_indices = times <= target_time
            plot_centroids_x = centroids_x[valid_indices]
            plot_centroids_y = centroids_y[valid_indices]
        else:
            plot_centroids_x = centroids_x
            plot_centroids_y = centroids_y
        
        # Define quadratic trajectory model
        def trajectory(t, a, b, c, d, e, f):
            x = a * t**2 + b * t + c
            y = d * t**2 + e * t + f
            return np.concatenate([x, y])
        
        # Try fitting a quadratic model, fallback to linear if needed
        try:
            with warnings.catch_warnings():
                warnings.simplefilter("error")
                popt, _ = curve_fit(trajectory, times, np.hstack((centroids_x, centroids_y)))
                a, b, c, d, e, f = popt
        except (RuntimeError, Warning):
            def linear_trajectory(t, m_x, c_x, m_y, c_y):
                x = m_x * t + c_x
                y = m_y * t + c_y
                return np.concatenate([x, y])
            popt, _ = curve_fit(linear_trajectory, times, np.hstack((centroids_x, centroids_y)))
            m_x, c_x, m_y, c_y = popt
            a, b, c, d, e, f = 0, m_x, c_x, 0, m_y, c_y  # Set quadratic terms to zero
        
        # Compute predicted position at target_time
        if a == 0 and d == 0:  # Linear case
            x_pred = b * target_time + c
            y_pred = e * target_time + f
            vx = b
            vy = e
        else:  # Quadratic case
            x_pred = a * target_time**2 + b * target_time + c
            y_pred = d * target_time**2 + e * target_time + f
            vx = 2 * a * target_time + b
            vy = 2 * d * target_time + e
        
        # Compute heading angle
        heading = np.degrees(np.arctan2(vx, vy)) % 360
        heading_arrow = (360 - heading + 90) % 360

        # Plot trajectory, centroids, and heading vector
        image = np.ones((1536, 1818), dtype=np.uint8) * 255  # Create white background
        plt.figure(figsize=(18, 15))

        # Plot selected centroid points
        cap_x = max(centroids_x) + 300
        cap_y = max(centroids_y) + 200
        plt.imshow(image, cmap='gray',  extent=[0, cap_x, 0, cap_y])  # Show the white image
        plt.scatter(plot_centroids_x, plot_centroids_y, c='red', marker='o', s=5, label='Centroid Points')

        # Plot heading vector at the predicted position
        plt.plot([x_pred, x_pred + 50 * np.cos(np.radians(heading_arrow))], [y_pred, y_pred + 50 * np.sin(np.radians(heading_arrow))], color='white', linewidth=3)
        plt.arrow(x_pred + 40 * np.cos(np.radians(heading_arrow)), y_pred + 40 * np.sin(np.radians(heading_arrow)), 10 * np.cos(np.radians(heading_arrow)), 10 * np.sin(np.radians(heading_arrow)), color='white', head_width=15, head_length=20)
        plt.text(x_pred + (50 * np.cos(np.radians(heading_arrow))) + 50, y_pred + (50 * np.sin(np.radians(heading_arrow))) + 30, f'{heading:.1f}°', color='white', fontsize=20)
        
        # Plot settings
        plt.title('Centroids and Heading', fontsize=32)
        plt.xlabel('X coordinates [µm]', fontsize=23)
        plt.ylabel('Y coordinates [µm]', fontsize=23)
        plt.tick_params(axis='both', which='major', labelsize=18)
        
        # Save the output image
        if not os.path.exists(output_folder_path):
            os.makedirs(output_folder_path)
        output_image_path = os.path.join(output_folder_path, "Centroid_and_Heading.png")
        plt.savefig(output_image_path)
        plt.close()
        
        print(f"The heading at time {target_time_original:.2f}s is: {heading:.2f} degrees.")



def compute_velocity_acceleration(h5_file_path, output_folder_path, microns_per_pixel):
    
    video_name = 'Video_1'
    contour_name = 'Contour_F0030_1'
    target_time_original = 35     #seconds in the video
    
    # Open HDF5 file and extract centroid data
    with h5py.File(h5_file_path, 'r') as file:
        video_folder = file.get(video_name)
        if video_folder is None:
            raise ValueError(f"Video {video_name} not found in the HDF5 file.")
        
        times, centroids_x, centroids_y = [], [], []

        #Time conversion
        target_time = target_time_original * time_equivalence

        
        for frame_folder_name in video_folder:
            match = re.search(r"Frame\s+(\d+)\s+Time\s+([\d.]+)s", frame_folder_name)
            if match:
                frame_time = float(match.group(2))
                
                frame_folder = video_folder[frame_folder_name]
                attributes_matrix_name = f"{contour_name}_Attributes"
                attributes_matrix = frame_folder.get(attributes_matrix_name)
                
                if attributes_matrix is not None:
                    attributes_data = attributes_matrix[...]
                    if attributes_data.shape[0] >= 4:
                        centroids_x.append(attributes_data[2])
                        centroids_y.append(attributes_data[3])
                        times.append(frame_time)
        
        # Sort data by time
        sorted_indices = np.argsort(times)
        times = np.array(times)[sorted_indices]
        times = times * time_equivalence
        centroids_x = np.array(centroids_x)[sorted_indices]
        centroids_y = np.array(centroids_y)[sorted_indices]
        centroids_x = centroids_x * microns_per_pixel
        centroids_y = centroids_y * microns_per_pixel
        
        if target_time < times[0]:
            raise ValueError("Target time is before the first recorded frame.")

        # Select data to plot based on target_time
        if target_time <= times[-1]:
            valid_indices = times <= target_time
            plot_centroids_x = centroids_x[valid_indices]
            plot_centroids_y = centroids_y[valid_indices]
        else:
            plot_centroids_x = centroids_x
            plot_centroids_y = centroids_y

        # Define quadratic trajectory model
        def trajectory(t, a, b, c, d, e, f):
            x = a * t**2 + b * t + c
            y = d * t**2 + e * t + f
            return np.concatenate([x, y])

        # Try fitting a quadratic model, fallback to linear if needed
        try:
            with warnings.catch_warnings():
                warnings.simplefilter("error")
                popt, _ = curve_fit(trajectory, times, np.hstack((centroids_x, centroids_y)))
                a, b, c, d, e, f = popt
        except (RuntimeError, Warning):
            def linear_trajectory(t, m_x, c_x, m_y, c_y):
                x = m_x * t + c_x
                y = m_y * t + c_y
                return np.concatenate([x, y])
            popt, _ = curve_fit(linear_trajectory, times, np.hstack((centroids_x, centroids_y)))
            m_x, c_x, m_y, c_y = popt
            a, b, c, d, e, f = 0, m_x, c_x, 0, m_y, c_y  # Set quadratic terms to zero
        
        # Compute velocity and acceleration at target_time
        if a == 0 and d == 0:  # Linear case
            vx = b
            vy = e
            ax = 0
            ay = 0
        else:  # Quadratic case
            vx = 2 * a * target_time + b
            vy = 2 * d * target_time + e
            ax = 2 * a
            ay = 2 * d

        # Compute predicted position at target_time and other parameters
        x_pred = a * target_time**2 + b * target_time + c
        y_pred = d * target_time**2 + e * target_time + f
        vx_value = 2 * a 
        vy_value = 2 * d 

        # Plot trajectory, centroids, velocity, and acceleration
        image = np.ones((1536, 1818), dtype=np.uint8) * 255  # Create white background
        plt.figure(figsize=(18, 15))

        # Plot selected centroid points
        cap_x = max(centroids_x) + 300
        cap_y = max(centroids_y) + 200
        plt.imshow(image, cmap='gray',  extent=[0, cap_x, 0, cap_y])  # Show the white image
        plt.scatter(plot_centroids_x, plot_centroids_y, c='red', marker='o', s=5, label='Centroid Points')

        # Arrow settings
        arrow_length = 45  # Fixed arrow size

        # Normalize and draw velocity vector
        norm_v = np.hypot(vx, vy)
        if norm_v > 0:
            vx_fixed, vy_fixed = (vx / norm_v * arrow_length, vy / norm_v * arrow_length)
            plt.arrow(x_pred, y_pred, vx_fixed, vy_fixed, color='white', head_width=15, head_length=20, linewidth=3, label='Velocity')

        # Normalize and draw acceleration vector
        norm_a = np.hypot(ax, ay)
        if norm_a > 0:
            ax_fixed, ay_fixed = (ax / norm_a * arrow_length, ay / norm_a * arrow_length)
            plt.arrow(x_pred, y_pred, ax_fixed, ay_fixed, color='yellow', head_width=15, head_length=20, linewidth=3, label='Acceleration')

        # Plot settings
        plt.title(f'Centroids, Velocity, and Acceleration at {target_time_original}s', fontsize=32)
        plt.xlabel('X coordinates [µm]', fontsize=23)
        plt.ylabel('Y coordinates [µm]', fontsize=23)
        plt.tick_params(axis='both', which='major', labelsize=18)

        # Save the output image
        if not os.path.exists(output_folder_path):
            os.makedirs(output_folder_path)
        output_image_path = os.path.join(output_folder_path, "Velocity_Acceleration.png")
        plt.savefig(output_image_path)
        plt.close()

        # Print results
        # Print results with proper case handling
        if a == 0 and d == 0:  # Linear case
            print(f"The trajectory is linear:")
            print(f"v_x(t) = {b:.5f}, v_y(t) = {e:.5f}")  # Constant velocity
            print(f"a_x = 0, a_y = 0 (No acceleration)")
        else:  # Quadratic case
            print(f"The trajectory is quadratic:")
            print(f"v_x(t) = {vx_value:.5f} * t + {b:.5f}, v_y(t) = {vy_value:.5f} * t + {e:.5f}")
            print(f"a_x = {ax:.5f}, a_y = {ay:.5f}")

        print(f"Velocity at t={target_time_original}s: ({vx:.5f}, {vy:.5f}) µm/µs")
        print(f"Acceleration at t={target_time_original}s: ({ax:.5f}, {ay:.5f}) µm/µs²")


def compute_velocity_comparison(h5_file_path, output_folder_path, microns_per_pixel):
    video_name = 'Video_1'
    contour_name = 'Contour_F0030_1'

    # Open HDF5 file and extract centroid data
    with h5py.File(h5_file_path, 'r') as file:
        video_folder = file.get(video_name)
        if video_folder is None:
            raise ValueError(f"Video {video_name} not found in the HDF5 file.")
        
        times, centroids_x, centroids_y = [], [], []
        
        for frame_folder_name in video_folder:
            match = re.search(r"Frame\s+(\d+)\s+Time\s+([\d.]+)s", frame_folder_name)
            if match:
                frame_time = float(match.group(2))
                
                frame_folder = video_folder[frame_folder_name]
                attributes_matrix_name = f"{contour_name}_Attributes"
                attributes_matrix = frame_folder.get(attributes_matrix_name)
                
                if attributes_matrix is not None:
                    attributes_data = attributes_matrix[...]
                    if attributes_data.shape[0] >= 4:
                        centroids_x.append(attributes_data[2])
                        centroids_y.append(attributes_data[3])
                        times.append(frame_time)
        
        # Sort data by time
        sorted_indices = np.argsort(times)
        times = np.array(times)[sorted_indices]
        times = times * time_equivalence
        centroids_x = np.array(centroids_x)[sorted_indices]
        centroids_y = np.array(centroids_y)[sorted_indices]
        centroids_x = centroids_x * microns_per_pixel
        centroids_y = centroids_y * microns_per_pixel
        
        # Define quadratic trajectory model
        def trajectory(t, a, b, c, d, e, f):
            x = a * t**2 + b * t + c
            y = d * t**2 + e * t + f
            return np.concatenate([x, y])

        # Try fitting a quadratic model, fallback to linear if needed
        try:
            with warnings.catch_warnings():
                warnings.simplefilter("error")
                popt, _ = curve_fit(trajectory, times, np.hstack((centroids_x, centroids_y)))
                a, b, c, d, e, f = popt
        except (RuntimeError, Warning):
            def linear_trajectory(t, m_x, c_x, m_y, c_y):
                x = m_x * t + c_x
                y = m_y * t + c_y
                return np.concatenate([x, y])
            popt, _ = curve_fit(linear_trajectory, times, np.hstack((centroids_x, centroids_y)))
            m_x, c_x, m_y, c_y = popt
            a, b, c, d, e, f = 0, m_x, c_x, 0, m_y, c_y  # Set quadratic terms to zero
        
        # Compute approximate velocity from the model
        if a == 0 and d == 0:  # Linear case
            approx_vx = np.full_like(times, b)
            approx_vy = np.full_like(times, e)
        else:  # Quadratic case
            approx_vx = 2 * a * times + b
            approx_vy = 2 * d * times + e
        approx_velocity = np.sqrt(approx_vx**2 + approx_vy**2)
        
        # Compute real velocity using finite differences
        real_vx = []
        real_vy = []
        real_velocity = []
        real_times = []

        for i in range(len(centroids_x) - 1):
            delta_x = centroids_x[i + 1] - centroids_x[i]
            delta_y = centroids_y[i + 1] - centroids_y[i]
            delta_t = times[i + 1] - times[i]

            vx = delta_x / delta_t
            vy = delta_y / delta_t
            velocity = np.sqrt(vx**2 + vy**2)

            real_vx.append(vx)
            real_vy.append(vy)
            real_velocity.append(velocity)
            real_times.append(times[i + 1])  # Asigna el tiempo del segundo punto del intervalo
        
        # Compute mean error
        min_length = min(len(real_velocity), len(approx_velocity))
        mean_error = np.mean(np.abs(real_velocity[:min_length] - approx_velocity[:min_length]))
        print(f"Mean velocity error: {mean_error:.2f} µm/µs")
        
        # Plot velocity comparison
        plt.figure(figsize=(10, 6))
        plt.plot(real_times, real_velocity, label='Real Velocity', color='blue', linestyle='-', marker='o')
        plt.plot(times, approx_velocity, label='Approximate Velocity', color='red', linestyle='--', marker='s')
        
        plt.xlabel('Time (µs)')
        plt.ylabel('Velocity (µm/µs)')
        plt.title('Comparison of Real and Approximate Velocities')
        plt.legend()
        plt.grid()
        
        # Save the plot
        if not os.path.exists(output_folder_path):
            os.makedirs(output_folder_path)
        output_image_path = os.path.join(output_folder_path, "Velocity_Comparison.png")
        plt.savefig(output_image_path, dpi=300)
        plt.close()

def compute_heading_comparison(h5_file_path, output_folder_path, microns_per_pixel):
    video_name = 'Video_1'
    contour_name = 'Contour_F0030_1'

    # Open HDF5 file and extract centroid data
    with h5py.File(h5_file_path, 'r') as file:
        video_folder = file.get(video_name)
        if video_folder is None:
            raise ValueError(f"Video {video_name} not found in the HDF5 file.")
        
        times, centroids_x, centroids_y = [], [], []
        
        for frame_folder_name in video_folder:
            match = re.search(r"Frame\s+(\d+)\s+Time\s+([\d.]+)s", frame_folder_name)
            if match:
                frame_time = float(match.group(2))
                
                frame_folder = video_folder[frame_folder_name]
                attributes_matrix_name = f"{contour_name}_Attributes"
                attributes_matrix = frame_folder.get(attributes_matrix_name)
                
                if attributes_matrix is not None:
                    attributes_data = attributes_matrix[...]
                    if attributes_data.shape[0] >= 4:
                        centroids_x.append(attributes_data[2])
                        centroids_y.append(attributes_data[3])
                        times.append(frame_time)
        
        # Sort data by time
        sorted_indices = np.argsort(times)
        times = np.array(times)[sorted_indices]
        times = times * time_equivalence
        centroids_x = np.array(centroids_x)[sorted_indices]
        centroids_y = np.array(centroids_y)[sorted_indices]
        centroids_x = centroids_x * microns_per_pixel
        centroids_y = centroids_y * microns_per_pixel
        
        # Define quadratic trajectory model
        def trajectory(t, a, b, c, d, e, f):
            x = a * t**2 + b * t + c
            y = d * t**2 + e * t + f
            return np.concatenate([x, y])
        
        # Fit a quadratic or linear model
        try:
            with warnings.catch_warnings():
                warnings.simplefilter("error")
                popt, _ = curve_fit(trajectory, times, np.hstack((centroids_x, centroids_y)))
                a, b, c, d, e, f = popt
        except (RuntimeError, Warning):
            def linear_trajectory(t, m_x, c_x, m_y, c_y):
                x = m_x * t + c_x
                y = m_y * t + c_y
                return np.concatenate([x, y])
            popt, _ = curve_fit(linear_trajectory, times, np.hstack((centroids_x, centroids_y)))
            m_x, c_x, m_y, c_y = popt
            a, b, c, d, e, f = 0, m_x, c_x, 0, m_y, c_y
        
        # Compute headings
        headings_approx = []
        headings_real = []
        for i in range(1, len(times)):
            dt = times[i] - times[i-1]
            if dt > 0:
                # Real heading
                vx_real = (centroids_x[i] - centroids_x[i-1]) / dt
                vy_real = (centroids_y[i] - centroids_y[i-1]) / dt
                heading_real = np.degrees(np.arctan2(vx_real, vy_real)) % 360
                headings_real.append(heading_real)
                
                # Approximate heading
                if a == 0 and d == 0:
                    vx_approx = b
                    vy_approx = e
                else:
                    vx_approx = 2 * a * times[i] + b
                    vy_approx = 2 * d * times[i] + e
                heading_approx = np.degrees(np.arctan2(vx_approx, vy_approx)) % 360
                headings_approx.append(heading_approx)
        
        # Compute mean error
        error_mean = np.mean(np.abs(np.array(headings_real) - np.array(headings_approx)))
        
        # Plot results
        plt.figure(figsize=(10, 6))
        plt.plot(times[1:], headings_real, label='Real Heading', marker='o', linestyle='-', color='blue')
        plt.plot(times[1:], headings_approx, label='Approximated Heading', marker='s', linestyle='--', color='red')
        plt.xlabel('Time [µs]')
        plt.ylabel('Heading [degrees]')
        plt.title('Heading Comparison')
        plt.legend()
        plt.grid()
        
        # Save the plot
        if not os.path.exists(output_folder_path):
            os.makedirs(output_folder_path)
        output_plot_path = os.path.join(output_folder_path, "Heading_Comparison.png")
        plt.savefig(output_plot_path)
        plt.close()
        
        print(f"Mean heading error: {error_mean:.2f} degrees")



def compute_acceleration_comparison(h5_file_path, output_folder_path, microns_per_pixel):
    video_name = 'Video_1'
    contour_name = 'Contour_F0030_1'

    # Open HDF5 file and extract centroid data
    with h5py.File(h5_file_path, 'r') as file:
        video_folder = file.get(video_name)
        if video_folder is None:
            raise ValueError(f"Video {video_name} not found in the HDF5 file.")
        
        times, centroids_x, centroids_y = [], [], []
        
        for frame_folder_name in video_folder:
            match = re.search(r"Frame\s+(\d+)\s+Time\s+([\d.]+)s", frame_folder_name)
            if match:
                frame_time = float(match.group(2))
                
                frame_folder = video_folder[frame_folder_name]
                attributes_matrix_name = f"{contour_name}_Attributes"
                attributes_matrix = frame_folder.get(attributes_matrix_name)
                
                if attributes_matrix is not None:
                    attributes_data = attributes_matrix[...]
                    if attributes_data.shape[0] >= 4:
                        centroids_x.append(attributes_data[2])
                        centroids_y.append(attributes_data[3])
                        times.append(frame_time)
        
        # Sort data by time
        sorted_indices = np.argsort(times)
        times = np.array(times)[sorted_indices]
        times = times * time_equivalence
        centroids_x = np.array(centroids_x)[sorted_indices]
        centroids_y = np.array(centroids_y)[sorted_indices]
        centroids_x = centroids_x * microns_per_pixel
        centroids_y = centroids_y * microns_per_pixel
        
        # Define quadratic trajectory model
        def trajectory(t, a, b, c, d, e, f):
            x = a * t**2 + b * t + c
            y = d * t**2 + e * t + f
            return np.concatenate([x, y])
        
        # Fit quadratic or linear model
        try:
            popt, _ = curve_fit(trajectory, times, np.hstack((centroids_x, centroids_y)))
            a, b, c, d, e, f = popt
        except RuntimeError:
            def linear_trajectory(t, m_x, c_x, m_y, c_y):
                x = m_x * t + c_x
                y = m_y * t + c_y
                return np.concatenate([x, y])
            popt, _ = curve_fit(linear_trajectory, times, np.hstack((centroids_x, centroids_y)))
            m_x, c_x, m_y, c_y = popt
            a, b, c, d, e, f = 0, m_x, c_x, 0, m_y, c_y  # Set quadratic terms to zero
        
        # Compute real acceleration
        real_vx = np.gradient(centroids_x, times)
        real_vy = np.gradient(centroids_y, times)
        real_ax = np.gradient(real_vx, times)
        real_ay = np.gradient(real_vy, times)
        real_acceleration = np.sqrt(real_ax**2 + real_ay**2)
        
        # Compute approximate acceleration
        approx_ax = np.full_like(times, 2 * a)
        approx_ay = np.full_like(times, 2 * d)
        approx_acceleration = np.sqrt(approx_ax**2 + approx_ay**2)
        
        # Compute mean error
        error = np.abs(real_acceleration - approx_acceleration)
        mean_error = np.mean(error)
        
        # Plot acceleration curves
        plt.figure(figsize=(10, 6))
        plt.plot(times, real_acceleration, label='Real Acceleration', color='blue')
        plt.plot(times, approx_acceleration, label='Approximate Acceleration', color='red', linestyle='dashed')
        plt.xlabel('Time (µs)')
        plt.ylabel('Acceleration (µm/µs²)')
        plt.title('Acceleration vs. Time')
        plt.legend()
        plt.grid()
        
        # Save the output image
        if not os.path.exists(output_folder_path):
            os.makedirs(output_folder_path)
        output_image_path = os.path.join(output_folder_path, "Acceleration_vs_Time.png")
        plt.savefig(output_image_path)
        plt.close()
        
        print(f"Mean acceleration error: {mean_error:.4f} µm/µs²")


def plot_smooth_centroids_every_5(h5_file_path, output_folder_path, microns_per_pixel):
    # Initial variables (to be filled with the video name and contour name)
    video_name = 'Video_1'  # Complete with the video name
    contour_name = 'Contour_F0030_1'  # Complete with the contour name

    # Open the HDF5 file
    with h5py.File(h5_file_path, 'r') as file:
        # Access the folder for the specific video
        video_folder = file.get(video_name)
        if video_folder is None:
            raise ValueError(f"Video {video_name} not found in the HDF5 file.")
        
        # Initialize lists to store centroid coordinates
        centroids_x = []
        centroids_y = []
        
        # Loop through all the frame folders
        for frame_folder_name in video_folder:
            # Check for folders that follow the format "Dataset: Frame XXXX Time X.XXs"
            if frame_folder_name.startswith("Dataset: Frame"):
                frame_folder = video_folder[frame_folder_name]
                
                # Build the name of the attributes matrix
                attributes_matrix_name = f"{contour_name}_Attributes"
                attributes_matrix = frame_folder.get(attributes_matrix_name)
                
                if attributes_matrix is not None:
                    # Extract the data from the attributes matrix
                    attributes_data = attributes_matrix[...]
                    
                    if attributes_data.shape[0] >= 4:
                        # Extract the centroid coordinates
                        centroid_x = attributes_data[2] * microns_per_pixel  # Third value
                        centroid_y = attributes_data[3] * microns_per_pixel # Fourth value
                        
                        # Store the centroid coordinates
                        centroids_x.append(centroid_x)
                        centroids_y.append(centroid_y)

        # Convert lists to numpy arrays
        centroids_x = np.array(centroids_x)
        centroids_y = np.array(centroids_y)

        # Apply filter to smooth the oscillations
        centroid_y_smooth = gaussian_filter1d(centroids_y, sigma=5)

        #Only 1 centroid of every 5
        centroids_x_5 = centroids_x[::5]
        centroid_y_smooth_5 = centroid_y_smooth[::5]

        # Create a blank image of the specified size (1536x1818)
        image = np.ones((1536, 1818), dtype=np.uint8) * 255  # White background

        # Plot all centroid points
        maxcap_x = max(centroids_x_5) + 100
        maxcap_y = max(centroid_y_smooth_5) + 100
        mincap_y = min(centroid_y_smooth_5) - 100

        plt.figure(figsize=(18, 15))  # Adjust the figure size to match the image aspect ratio
        plt.imshow(image, cmap='gray', extent=[0, maxcap_x, mincap_y, maxcap_y])  # Show the white image
        plt.scatter(centroids_x_5, centroid_y_smooth_5, c='red', marker='o', label='Centroid Points', s=5)

        # Add labels and title
        plt.title('Centroid Points', fontsize=32)
        plt.xlabel('X coordinates [µm]', fontsize=23)
        plt.ylabel('Y coordinates [µm]', fontsize=23)
        plt.tick_params(axis='both', which='major', labelsize=18)

        # Ensure the output directory exists
        if not os.path.exists(output_folder_path):
            os.makedirs(output_folder_path)
        
        # Define the output image path
        output_image_path = os.path.join(output_folder_path, "Centroid_Trajectory_Smooth.png")

        # Save the image to the specified path
        plt.savefig(output_image_path)
        plt.close() 