import cv2
import numpy as np
import matplotlib.pyplot as plt
import operator # for sorting and comparing
import pyefd
import os
import time
import h5py
import re

from ImageProcessing import convert_to_grayscale
from ImageProcessing import crop_and_remove_nozzle
from ImageProcessing import noise_reduction
from ImageProcessing import binarization

from ContourProcessing import contour_detection
from ContourProcessing import contour_selection

def processing(path):
    # Iterate over each folder in path
       for folder in os.listdir(path):
            folder_path = os.path.join(path, folder)

            # Skip if it's not a folder
            if not os.path.isdir(folder_path):
                continue

            # Define the path to the "Initial Frames" and "Processed Frames" folders
            initial_frames_folder = os.path.join(folder_path, 'Initial Frames')
            processed_frames_folder = os.path.join(folder_path, 'Processed Frames')

            # If "Processed Frames" folder is not empty, skip this folder
            if os.path.exists(processed_frames_folder) and os.listdir(processed_frames_folder):
                continue  # Skip if already processed

            # If "Initial Frames" folder exists, process the images and save them in "Processed Frames" 
            if os.path.exists(initial_frames_folder):

                # Create "Processed Frames" folder if it doesn't exist
                os.makedirs(processed_frames_folder, exist_ok=True)

                # Get all image files in the "Initial Frames" folder
                for image_file in os.listdir(initial_frames_folder):
                    
                    image_path = os.path.join(initial_frames_folder, image_file)

                    # Process each image if it is a file (not a directory)
                    if os.path.isfile(image_path):

                        # Read the image
                        image = cv2.imread(image_path)

                        # Convert to grayscale
                        grayscale_image = convert_to_grayscale(image)
                        if grayscale_image is None:
                            print(f"Error in converting to grayscale for {image_file}.")
                            continue  # Skip this image

                        # Crop and remove the nozzle
                        cropped_image = crop_and_remove_nozzle(grayscale_image)
                        if cropped_image is None:
                            print(f"Error in cropping the image for {image_file}.")
                            continue  # Skip this image

                        # Apply noise reduction
                        blurred_image = noise_reduction(cropped_image)
                        if blurred_image is None:
                            print(f"Error in noise reduction for {image_file}.")
                            continue  # Skip this image

                        # Apply binarization
                        binary_image = binarization(blurred_image)
                        if binary_image is None:
                            print(f"Error in binarizing the image for {image_file}.")
                            continue  # Skip this image

                        # Save the processed (binarized) image to "Processed Frames"
                        processed_image_path = os.path.join(processed_frames_folder, image_file)
                        cv2.imwrite(processed_image_path, binary_image)  # Save the image
    


def processing_contours(path, h5_path):
    # Iterate over each folder in the path
    for folder in os.listdir(path):

        folder_path = os.path.join(path, folder)
        # Skip if it's not a folder
        if not os.path.isdir(folder_path):
            continue

        # Define paths for processed frames
        processed_frames_folder = os.path.join(folder_path, 'Processed Frames')

        # Get all image files in the "Processed Frames" folder
        for image_file in os.listdir(processed_frames_folder):
            image_path = os.path.join(processed_frames_folder, image_file)

            # Process each image if it is a file
            if os.path.isfile(image_path):
                # Read the image
                image = cv2.imread(image_path)
                image_name = os.path.basename(image_path)

                # Extract attributes (V, W, D), frame, and time from the filename
                attributes = re.findall(r'([VWD]\d+)-(-?\d+)', image_file, re.IGNORECASE)
                attr_dict = {attr[0].lower(): int(attr[1]) for attr in attributes}

                # Extract frame and time
                frame_time_info = re.search(r'frame(\d+)_time([\d.]+)s', image_file)
                if frame_time_info:
                    frame = frame_time_info.group(1)
                    time = frame_time_info.group(2)
                else:
                    print(f"Invalid frame-time format for {image_file}. Skipping.")
                    continue

                # Open the H5 file
                with h5py.File(h5_path, 'a') as h5_file:
                    matching_group = None

                    # Search for the group that matches the attributes
                    for group_name in h5_file.keys():
                        group = h5_file[group_name]
                        attributes_group = group.get("Attributes")
                        if attributes_group is not None:
                            if all(attributes_group.attrs.get(k) == v for k, v in attr_dict.items()):
                                matching_group = group
                                break

                    if matching_group is None:
                        print(f"No matching group found for attributes in {image_file}. Skipping.")
                        continue

                    # Construct the name of the dataset based on the frame and time
                    dataset_name = f"Dataset: Frame {frame.zfill(4)} Time {time}s"

                    # Check if the dataset exists
                    if dataset_name not in matching_group.keys():
                        print(f"Subgroup {dataset_name} not found in {matching_group}. Skipping.")
                        continue

                    dataset_group = matching_group[dataset_name]

                    # Check if the dataset already contains data
                    if len(dataset_group.keys()) > 0:  # If dataset already has contours, skip processing
                        continue

                    # Perform contour detection
                    image_to_draw, contour_image, contours, hierarchy, image_shape = contour_detection(image)
                    if image_to_draw is None or contour_image is None or image_shape is None:
                        print(f"Error in {image_file}. Skipping.")
                        continue

                    # Perform contour selection
                    selected_contours, image_to_draw = contour_selection(contours, hierarchy, image_shape, contour_image, image_name)
                    if selected_contours is None:
                        print(f"Error in contour selection for {image_file}. Skipping.")
                        continue

                    # Parameters
                    max_points = 10000  # Maximum number of points per contour (to ensure fixed size)

                    # Process and save the contours
                    for idx, contour in enumerate(selected_contours, start=1):  # Start enumeration at 1
                        # Flatten the contour into a single list
                        points = contour.flatten()

                        # Reshape points into two columns (x and y)
                        num_points = len(points) // 2  # Number of actual points in the contour
                        reshaped_points = np.zeros((max_points, 2), dtype=np.float32)  # Preallocate with zeros

                        if num_points > 0:
                            # Fill reshaped_points with available data
                            reshaped_points[:num_points, 0] = points[::2]  # x-coordinates
                            reshaped_points[:num_points, 1] = points[1::2]  # y-coordinates

                        # Transpose the reshaped_points to make coordinates vertical
                        reshaped_points = reshaped_points.T  # Transpose the matrix

                        # Create a dataset for the current contour
                        contour_name = f"Contour_{idx}"  # Dataset names start from Contour_1

                        # Check if the contour sub-group already exists
                        if contour_name in dataset_group:
                            continue  # Skip if the contour sub-group already exists

                        # Save the contour data
                        dataset_group.create_dataset(contour_name, data=reshaped_points, dtype='float32')

                        # Calculate contour attributes
                        perimeter = cv2.arcLength(contour, closed=True)  # Perimeter
                        area = cv2.contourArea(contour)  # Area

                        # Calculate Centroid
                        moments = cv2.moments(contour)
                        if moments["m00"] != 0:
                            centroid_x = moments["m10"] / moments["m00"]
                            centroid_y = moments["m01"] / moments["m00"]
                        else:
                            centroid_x, centroid_y = 0.0, 0.0  # Default if the contour is degenerate

                        # Calculate Hu Moments
                        hu_moments = cv2.HuMoments(moments).flatten()  # Flatten to a 1D array (7 elements)

                        # Create the attributes dataset
                        attributes_name = f"{contour_name}_Attributes"  # Example: Contour_1_Attributes
                        # Combine area, perimeter, centroid, and Hu Moments into a single array
                        attributes_data = np.concatenate(([area, perimeter, centroid_x, centroid_y], hu_moments)).astype(np.float32)

                        # Save the attributes matrix
                        dataset_group.create_dataset(attributes_name, data=attributes_data, dtype='float32')



def processing_contour_images(path, h5_path):
    # Iterate over each folder in the path
    for folder in os.listdir(path):

        folder_path = os.path.join(path, folder)
        # Skip if it's not a folder
        if not os.path.isdir(folder_path):
            continue

        # Define paths for processed frames and selected contours folders
        processed_frames_folder = os.path.join(folder_path, 'Processed Frames')
        selected_contours_frames_folder = os.path.join(folder_path, 'Frames with selected contours')

        # Create "Frames with selected contours" folder if it doesn't exist
        os.makedirs(selected_contours_frames_folder, exist_ok=True)

        # Skip processing if the "Frames with selected contours" folder is not empty
        if os.listdir(selected_contours_frames_folder):  # If folder is not empty, skip
            continue

        # Get all image files in the "Processed Frames" folder
        for image_file in os.listdir(processed_frames_folder):
            image_path = os.path.join(processed_frames_folder, image_file)

            # Process each image if it is a file
            if os.path.isfile(image_path):
                # Read the image
                image = cv2.imread(image_path)
                image_name = os.path.basename(image_path)

                # Perform contour detection
                image_to_draw, contour_image, contours, hierarchy, image_shape = contour_detection(image)
                if image_to_draw is None or contour_image is None or image_shape is None:
                    print(f"Error in {image_file}. Skipping.")
                    continue

                # Perform contour selection
                selected_contours, image_to_draw = contour_selection(contours, hierarchy, image_shape, contour_image, image_name)
                if selected_contours is None:
                    print(f"Error in contour selection for {image_file}. Skipping.")
                    continue

                # Draw centroids on the image
                for contour in selected_contours:
                    # Calculate Centroid
                    moments = cv2.moments(contour)
                    if moments["m00"] != 0:
                        centroid_x = int(moments["m10"] / moments["m00"])  # Convert to integer for drawing
                        centroid_y = int(moments["m01"] / moments["m00"])  # Convert to integer for drawing

                        # Draw the centroid as a small circle in blue (BGR: (255, 0, 0))
                        cv2.circle(image_to_draw, (centroid_x, centroid_y), radius=5, color=(255, 0, 0), thickness=-1)  # Blue filled circle

                # Save the image with centroids
                selected_image_path = os.path.join(selected_contours_frames_folder, image_name)
                if not os.path.exists(selected_image_path):
                    cv2.imwrite(selected_image_path, image_to_draw)  # Save the image