import cv2
import numpy as np
import matplotlib.pyplot as plt
import operator # for sorting and comparing
import pyefd
import os
import time
import h5py
import re



#OBTAIN ATTRIBUTES OF THE VIDEO
def create_h5_file_with_groups(h5_path, folder_path):
    # Open the HDF5 file, creating it if it doesn't exist
    if not os.path.exists(h5_path):
        h5_file = h5py.File(h5_path, 'w')
    else:
        h5_file = h5py.File(h5_path, 'a')

    try:
        # Extract folder names
        folder_names = [name for name in os.listdir(folder_path) if os.path.isdir(os.path.join(folder_path, name))]

        for folder_name in folder_names:
            # Extract attributes from folder name using regex
            attributes = re.findall(r'([Vwd]\d+)-(-?\d+)', folder_name, re.IGNORECASE)
            attr_dict = {attr[0].lower(): int(attr[1]) for attr in attributes}  # Store as lowercase

            # Check if a group with these attributes already exists
            group_found = None
            for group_name in h5_file.keys():
                group = h5_file[group_name]
                attributes_group = group.get("Attributes")  # Access the 'Attributes' subgroup
                if attributes_group is not None:
                    # Check if the attributes match with the ones in the 'Attributes' subgroup
                    if all(attributes_group.attrs.get(k) == v for k, v in attr_dict.items()):
                        group_found = group
                        break

            # Create a new group if no matching group is found
            if not group_found:
                new_group_name = f"Video_{len(h5_file.keys()) + 1}"
                group_found = h5_file.create_group(new_group_name)
                attributes_group = group_found.create_group("Attributes")
                for k, v in attr_dict.items():
                    attributes_group.attrs[k] = v

            # Proceed only if a valid group is found
            if group_found is None:
                raise ValueError("Failed to create or find a valid group.")

            # Look for "Initial Frames" subfolder inside the current folder
            initial_frames_path = os.path.join(folder_path, folder_name, "Initial Frames")
            if os.path.exists(initial_frames_path) and os.path.isdir(initial_frames_path):
                # Extract all frame files
                frame_files = [file for file in os.listdir(initial_frames_path) if file.endswith(".png") or file.endswith(".jpg")]

                for frame_file in frame_files:
                    # Extract frame and time information using regex
                    match = re.search(r'frame(\d+)_time([\d.]+)s', frame_file, re.IGNORECASE)
                    if match:
                        frame = match.group(1)  # Extract frame number
                        time = match.group(2)  # Extract time in seconds
                        dataset_name = f"Dataset: Frame {frame} Time {time}s"

                        # Check if the dataset group already exists
                        if dataset_name not in group_found.keys():
                            group_found.create_group(dataset_name)  # Create a group for this frame and time
                            
    except (OSError, ValueError, h5py.H5Error) as e:
        print(f"Error: {e}")

    finally:
        h5_file.close()
