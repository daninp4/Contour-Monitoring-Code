import cv2
import numpy as np
import matplotlib.pyplot as plt
import operator 
import pyefd
import os
import time
import h5py
import re



# CROPPING --> NOISE REDUTION --> BLUR --> BINARIZATION

# CONVERT AN IMAGE TO GRAYSCALE
def convert_to_grayscale(image):
    try:

        # Verify if the image is valid.
        if image is None:
            raise ValueError("The provided image is invalid.")
        
        # Conver the image to grayscale
        try:
            blacknwhite = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)
        except cv2.error as e:
            raise ValueError("Error converting the image to grayscale.") from e
        
        # Create a CLAHE object.
        # ClipLimit controls the contrast level. The higher the value, the greater the contrast and noise.
        # TileGridSize defines the size of the tiles or regions into which the image is divided.
        # When the tile size is smaller (4, 4) -> the contrast adjustment is applied to smaller regions, which can lead to abrupt transitions.
        # If the tile size is larger (16, 16) -> the contrast adjustment is applied to larger areas, giving a smoother effect but potentially losing small local details.
        try:
            clahe = cv2.createCLAHE(clipLimit = 2.0, tileGridSize = (8, 8))
            clahe_image = clahe.apply(blacknwhite)
        except cv2.error as e:
            raise RuntimeError("Error applying the CLAHE algorithm to the image.") from e
        
        # save_path = "C:/Users/danin/Desktop/TFG/CODE DANI/Test/Grayscale2-16-16.jpg"
        # cv2.imwrite(save_path, clahe_image)

        return clahe_image
    
    except ValueError as ve:
        print(ve)
    except RuntimeError as re:
        print(re)
    except Exception as e:
        print(f"An unexpected error occurred: {e}")


# CROP THE IMAGE
def crop_and_remove_nozzle(image, x_offset=230, y_offset=0):
    
    try:
        # Check if the image is valid (not None and of correct type).
        if image is None or not isinstance(image, np.ndarray):
            raise ValueError("Invalid image input. Please provide a valid image.")
        
        # Get the dimensions of the image (height, width).
        height, width = image.shape[:2]

        # Validate that x_offset and y_offset are within the image bounds.
        if x_offset < 0 or x_offset >= width:
            raise ValueError(f"x_offset is out of bounds. It should be between 0 and {width - 1}.")
        if y_offset < 0 or y_offset >= height:
            raise ValueError(f"y_offset is out of bounds. It should be between 0 and {height - 1}.")

        # Crop the image from the given x_offset and y_offset.
        cropped = image[y_offset:, x_offset:]

        # Check if the crop resulted in an empty image.
        if cropped.size == 0:
            raise ValueError("The crop resulted in an empty image. Please check the offsets.")

        # save_path = "C:/Users/danin/Desktop/TFG/CODE DANI/Test/AfterCrop.jpg"
        # cv2.imwrite(save_path, cropped)

        return cropped

    except Exception as e:
        print(f"Error while cropping the image: {e}")
        return None
    


# NOISE REDUCTION --> GAUSSIAN BLUR
def noise_reduction(image):
    try:

        # Check if the image is valid (not None and of correct type).
        if image is None or not isinstance(image, np.ndarray):
            raise ValueError("Invalid image input. Please provide a valid image.")
        
        # Apply Gaussian blur to reduce noise.
        # The values inside the parenthesis (kernel numbers) must be odd and greater than 1 --> (3, 3), (5, 5)...
        # A larger kernel --> stronger blur and remove more noise, may blur important details of the image.
        # A smaller kernel --> lesser blur and noise reduction, but will preserve more details.
        # The value after kernel determines the amount of blur applied in the horizontal direction.
        # The 0 can be used to calculate it automatically.
        after_blur = cv2.GaussianBlur(image, (5, 5), 0)

        # save_path = "C:/Users/danin/Desktop/TFG/CODE DANI/Test/NoiseReduction3-3.jpg"
        # cv2.imwrite(save_path, after_blur)

        return after_blur
    
    except Exception as e:
        print(f"An error occurred: {e}")
        return None



# BINARIZATION
def binarization(image):

    try:

        # Check if the image is valid (not None and of correct type).
        if image is None or not isinstance(image, np.ndarray):
            raise ValueError("Invalid image input. Please provide a valid image.")
        
        # Binarize the image.
        # The first parameter is the threshold; all pixels below this value are set to 0.
        # All pixels above this value are set to 255 (255 == white and 0 == black). 
        # Result: binary image where there are only two values: 0 and 255.
        # The [1] is used to only return the image and not the binarization values.
        binary_image = cv2. threshold(image, 50, 255, cv2.THRESH_BINARY)[1]

        # save_path = "C:/Users/danin/Desktop/TFG/CODE DANI/Test/Binarization38.jpg"
        # cv2.imwrite(save_path, binary_image)

        return binary_image
    
    except Exception as e:
        print(f"An error occurred: {e}")
        return None