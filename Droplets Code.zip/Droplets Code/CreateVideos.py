import cv2
import numpy as np
import matplotlib.pyplot as plt
import operator # for sorting and comparing
import pyefd
import os
import time
import h5py
import re
import subprocess
import shutil



def create_videos_from_frames(input_path, output_path):
    try:
        # Validate paths
        if not os.path.exists(input_path):
            raise FileNotFoundError(f"Input path does not exist: {input_path}")
        
        # Create the output directory if it doesn't exist
        if not os.path.exists(output_path):
            os.makedirs(output_path)

        # Iterate over the folders in the main directory
        for folder in os.listdir(input_path):
            folder_path = os.path.join(input_path, folder)

            # Check if it's a directory
            if not os.path.isdir(folder_path):
                continue

            # Path to the "Frames for video" subdirectory
            frames_for_video_path = os.path.join(folder_path, "Frames for video")
            if not os.path.exists(frames_for_video_path):
                print(f"Subdirectory not found: {frames_for_video_path}")
                continue

            # Ensure there are images in the folder
            images = [img for img in os.listdir(frames_for_video_path) if img.endswith(('.png'))]
            if not images:
                continue

            # Sort images by frame number (based on the new naming format)
            images.sort(key=lambda x: int(x.split("frame")[1].split(".")[0].lstrip('0') or '0'))

            # Define the name of the output video with .mkv extension
            video_name = f"VideoContours_{folder}.mkv"  # Change to .mkv
            video_output_path = os.path.join(output_path, video_name)  # Directly save to output_path

            # Check if the video already exists
            if os.path.exists(video_output_path):
                continue

            # Generate a temporary text file with paths to images for ffmpeg
            temp_file = os.path.normpath(os.path.join(frames_for_video_path, "images.txt"))
            with open(temp_file, "w") as file:
                for img in images:
                    file.write(f"file '{os.path.join(frames_for_video_path, img)}'\n")

            # Use ffmpeg to create the video with the correct frame rate handling
            command = [
                "ffmpeg",
                "-y",  # Overwrite output file if it exists
                "-f", "concat",  # Use concatenation mode
                "-safe", "0",  # Disable safe paths check
                "-r", "30",  # Hardcoded frame rate of 30
                "-i", temp_file,  # Input file with image paths
                "-fps_mode", "passthrough",  # Handle frame rate properly
                "-pix_fmt", "yuv420p",  # Format for video
                video_output_path  # Output video path
            ]

            # Suppress the output and errors from ffmpeg
            subprocess.run(command, check=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE)

            # Remove the temporary file
            os.remove(temp_file)

    except Exception as e:
        print(f"An error occurred: {e}")




def create_frames_for_video(input_path):
    try:
        # Iterate over the folders in the main directory
        for folder in os.listdir(input_path):
            folder_path = os.path.join(input_path, folder)

            # Check if it's a directory
            if not os.path.isdir(folder_path):
                continue

            # Paths to the "Frames for video" and "Frames with selected contours"
            frames_for_video_path = os.path.join(folder_path, "Frames for video")
            frames_with_contours_path = os.path.join(folder_path, "Frames with selected contours")

            # Create "Frames for video" folder if it doesn't exist
            if not os.path.exists(frames_for_video_path):
                os.makedirs(frames_for_video_path)

            # Check if "Frames for video" already has images to avoid overwriting
            if os.listdir(frames_for_video_path):
                continue  # Skip to the next folder

            # Ensure the "Frames with selected contours" folder exists
            if not os.path.exists(frames_with_contours_path):
                continue

            # Get all the images in "Frames with selected contours" folder
            images = [img for img in os.listdir(frames_with_contours_path) if img.endswith(('.png', '.jpg', '.jpeg'))]
            if not images:
                continue

            # Sort images by the frame number in the filename
            images.sort(key=lambda x: int(x.split("_frame")[1].split("_time")[0].lstrip('0') or '0'))

            # Copy images from "Frames with selected contours" to "Frames for video"
            for i, img in enumerate(images, 1):
                source_image_path = os.path.join(frames_with_contours_path, img)
                destination_image_path = os.path.join(frames_for_video_path, f"frame{str(i).zfill(4)}.png")

                # Copy and rename the image
                shutil.copy(source_image_path, destination_image_path)

    except Exception as e:
        print(f"An error occurred: {e}")

