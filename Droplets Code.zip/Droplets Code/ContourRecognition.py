import cv2
import numpy as np
import matplotlib.pyplot as plt
import operator # for sorting and comparing
import pyefd
import os
import time
import h5py
import re
import subprocess
import shutil


from scipy.optimize import linear_sum_assignment

# Define thresholds and weights for the cost metrics
CENTROID_THRESHOLD = 50  # Example threshold for centroid distance
AREA_THRESHOLD = 0.3  # Example threshold for relative area difference
HU_THRESHOLD = 0.1  # Example threshold for Hu-moment distance
CENTROID_WEIGHT = 0.5  # Weight for centroid distance in cost calculation
AREA_WEIGHT = 0.25  # Weight for area difference in cost calculation
HU_WEIGHT = 0.25  # Weight for Hu-moment distance in cost calculation

# Function to calculate the Euclidean distance between two centroids
def calculate_centroid_distance(centroid1, centroid2):
    return np.linalg.norm(np.array(centroid1) - np.array(centroid2))

# Function to calculate the relative area difference between two areas
def calculate_relative_area_difference(area1, area2):
    return abs(area1 - area2) / max(area1, area2)

# Function to calculate the Euclidean distance between two sets of Hu moments
def calculate_hu_distance(hu1, hu2):
    return np.linalg.norm(np.array(hu1) - np.array(hu2))

# Function to check if the contour is touching the left edge of the image
def is_contour_touching_edges(contour_points):
    x_coords = contour_points[0]  # First element contains all x coordinates
    y_coords = contour_points[1]  # Second element contains all y coordinates
    
    for x, y in zip(x_coords, y_coords):  # Pair x and y coordinates
        if x == 0 and y != 0:  # Check if the contour touches the left margin
            return True
    return False


# Function to process the video file and perform contour matching across frames
def process_video_file(h5_path, folder_path):
    # Check if the folder exists, and clear its contents if it does
    if os.path.exists(folder_path):
        for filename in os.listdir(folder_path):
            file_path = os.path.join(folder_path, filename)
            try:
                if os.path.isfile(file_path) or os.path.islink(file_path):
                    os.unlink(file_path)  # Remove files or symbolic links
                elif os.path.isdir(file_path):
                    shutil.rmtree(file_path)  # Remove directories
            except Exception as e:
                print(f"Error deleting {file_path}: {e}")
    else:
        os.makedirs(folder_path)  # Create the folder if it doesn't exist

    # Copy the HDF5 file to the folder
    copied_file_path = os.path.join(folder_path, "DataVideos.h5")
    shutil.copy(h5_path, copied_file_path)
    
    with h5py.File(copied_file_path, 'r+') as h5_file:  # Open the HDF5 file in read-write mode
        for video_key in h5_file.keys():  # Loop through all video groups in the file
            video_group = h5_file[video_key]

            previous_contours = []  # Store attributes of previous frame contours
            previous_names = []  # Store names of previous frame contours

            frame_number = 0  # Start with frame 0000
            previous_frame_key = None
            matching_frames = None
            while True:
                # Format the frame key for the current frame number
                frame_key = f"Dataset: Frame {frame_number:04d} Time "
                
                previous_frame_key = matching_frames[0] if matching_frames else None
                # Search for a frame that starts with this key
                matching_frames = [
                    key for key in video_group.keys() if key.startswith(frame_key)
                ]
                
                if not matching_frames:
                    # If no matching frame is found, exit the loop
                    break

                # Assume there is only one matching frame per number
                frame_key = matching_frames[0]
                frame_group = video_group[frame_key]  # Access the current frame group

                current_contours = []  # Store contours of the current frame
                current_attributes = []  # Store attributes of the current frame

                # Collect current frame contours and attributes
                for dataset_name in frame_group.keys():
                    if dataset_name.endswith("_Attributes"):  # Identify datasets containing attributes
                        attributes = frame_group[dataset_name][:]  # Load attributes
                        current_attributes.append(attributes)

                        contour_name = dataset_name.replace("_Attributes", "")  # Get contour name
                        contour_points = frame_group[contour_name][:]  # Load contour points
                        current_contours.append((contour_name, contour_points, attributes))

                # If it's the first processed frame or the previous one doesn't have contours, assign unique names for contours
                if frame_number == 0 or (previous_frame_key and not any(isinstance(v, h5py.Dataset) for v in video_group.get(previous_frame_key, {}).values())):
                    for idx, (contour_name, _, attributes) in enumerate(current_contours, start=1):
                        new_name = f"Contour_F{frame_number:04d}_{idx}"

                        # Rename datasets for the first frame
                        frame_group[new_name] = frame_group[contour_name][:]
                        frame_group[new_name + "_Attributes"] = frame_group[contour_name + "_Attributes"][:]

                        del frame_group[contour_name]  # Delete original datasets
                        del frame_group[contour_name + "_Attributes"]

                        previous_contours.append(attributes)  # Save attributes for matching
                        previous_names.append(new_name)  # Save new name for future reference

                else:
                    # Validate there are previous and current contours
                    if not current_contours:
                        print(f"Warning: Skipping Frame {frame_number:04d} due to missing contours.")
                        frame_number += 1
                        continue

                    # Calculate cost matrix for matching contours
                    cost_matrix = []

                    # Iterating over all previous contours
                    for prev_attr in previous_contours:
                        prev_area = prev_attr[0]
                        prev_perimeter = prev_attr[1]
                        prev_centroidx = prev_attr[2]
                        prev_centroidy = prev_attr[3]
                        prev_hu = prev_attr[4:11]

                        row = []
                        # Iterating over all current contours
                        for _, contour_points, curr_attr in current_contours:
                            curr_area = curr_attr[0]
                            curr_perimeter = curr_attr[1]
                            curr_centroidx = curr_attr[2]
                            curr_centroidy = curr_attr[3]
                            curr_hu = curr_attr[4:11]

                            # Check if current contour touches the edges of the image
                            if is_contour_touching_edges(contour_points):
                                # Use centroid and area cost only
                                d_centroid = calculate_centroid_distance(
                                    (prev_centroidx, prev_centroidy), (curr_centroidx, curr_centroidy))
                                d_area = calculate_relative_area_difference(prev_area, curr_area)

                                if d_centroid > CENTROID_THRESHOLD or d_area > AREA_THRESHOLD:
                                    row.append(1e6)  # Invalid match
                                else:
                                    cost = (0.7 * d_centroid + 0.3 * d_area)  # Updated weights for edge-touching contours
                                    row.append(cost)
                            else:
                                # Use centroid, area, and Hu cost
                                d_centroid = calculate_centroid_distance(
                                    (prev_centroidx, prev_centroidy), (curr_centroidx, curr_centroidy))
                                d_area = calculate_relative_area_difference(prev_area, curr_area)
                                d_hu = calculate_hu_distance(prev_hu, curr_hu)

                                if d_centroid > CENTROID_THRESHOLD or d_area > AREA_THRESHOLD or d_hu > HU_THRESHOLD:
                                    row.append(1e6)  # Invalid match
                                else:
                                    cost = (CENTROID_WEIGHT * d_centroid + AREA_WEIGHT * d_area + HU_WEIGHT * d_hu)
                                    row.append(cost)

                        cost_matrix.append(row)  # Append the row for the current previous contour

                    # Validate the cost matrix
                    if not cost_matrix or not any(cost_matrix):
                        print(f"Warning: Cost matrix is empty or invalid for Frame {frame_number:04d}. Skipping.")
                        frame_number += 1
                        continue

                    cost_matrix = np.array(cost_matrix)  # Convert to numpy array for optimization
                    if cost_matrix.ndim != 2 or cost_matrix.size == 0:
                        print(f"Error: Invalid cost matrix for Frame {frame_number:04d}. Skipping.")
                        frame_number += 1
                        continue

                    # Apply the Hungarian algorithm to find the optimal matching
                    row_ind, col_ind = linear_sum_assignment(cost_matrix)

                    assigned_previous = set(row_ind)
                    assigned_current = set(col_ind)

                    # Update names for matched contours
                    for r, c in zip(row_ind, col_ind):
                        if cost_matrix[r, c] == float('inf'):
                            continue

                        prev_name = previous_names[r]
                        curr_name, _, _ = current_contours[c]

                        frame_group[prev_name] = frame_group[curr_name][:]
                        frame_group[prev_name + "_Attributes"] = frame_group[curr_name + "_Attributes"][:]

                        del frame_group[curr_name]
                        del frame_group[curr_name + "_Attributes"]

                    # Handle new contours
                    unassigned_current = set(range(len(current_contours))) - assigned_current
                    for new_idx, c in enumerate(unassigned_current, start=1):
                        curr_name, _, _ = current_contours[c]
                        new_name = f"Contour_F{frame_number:04d}_{new_idx}"

                        frame_group[new_name] = frame_group[curr_name][:]
                        frame_group[new_name + "_Attributes"] = frame_group[curr_name + "_Attributes"][:]

                        del frame_group[curr_name]
                        del frame_group[curr_name + "_Attributes"]

                    # Update previous_contours and previous_names by reading directly from the HDF5 file
                    previous_names = []
                    previous_contours = []

                    # Iterate through the dataset names in the current frame group
                    for dataset_name in frame_group.keys():
                        if dataset_name.endswith("_Attributes"):  # Identify datasets containing attributes
                            attributess = frame_group[dataset_name][:]  # Read attributes directly from the file
                            contour_namee = dataset_name.replace("_Attributes", "")  # Extract the contour name

                            previous_names.append(contour_namee)  # Add the updated name
                            previous_contours.append(attributess)  # Add the updated attributes


                # Increment the frame number for the next iteration
                frame_number += 1



