import cv2
import numpy as np
import matplotlib.pyplot as plt
import operator # for sorting and comparing
import pyefd
import os
import time
import h5py
import re



# DETECTION --> SELECTION

#CONTOUR DETENCTION
def contour_detection(image):
    try:
        # Check if the image is valid
        if image is None or not isinstance(image, np.ndarray):
            raise ValueError("Invalid image input. Please provide a valid image.")

        # Use Canny to detect all edges (both internal and external)
        # 2 threshold values (100 and 200):
        #    Threshold1: pixels with gradient values below this threshold are considered non-edges and are discarded; 
        #                increasing this value reduces sensitivity, resulting in fewer detected edges.
        #    Threshold2: pixels with gradient values above this threshold are considered definite edges; 
        #                increasing this value will capture only the strongest edges, potentially missing weaker ones.
        edges = cv2.Canny(image, 100, 200)

        # Find contours from the Canny edge-detected image
        contours, hierarchy = cv2.findContours(edges, cv2.RETR_TREE, cv2.CHAIN_APPROX_SIMPLE)
        contours = list(contours)

        # Check if the contours are detected correctly
        if contours is None or len(contours) == 0:
            return None, None, None, None, None

        # Draw the detected contours on the original image in green color (0, 255, 0). OPTIONAL.
        # -1 draws all contours, 2 is the line thickness
        contour_image = image.copy()

        # Ensure compatibility with PNG format (grayscale images with one channel)
        if len(contour_image.shape) == 2:
            image_to_draw = cv2.cvtColor(contour_image, cv2.COLOR_GRAY2BGR)
        else:
            image_to_draw = contour_image.copy()

        cv2.drawContours(image_to_draw, contours, -1, (0, 255, 0), 2)
        image_shape = image_to_draw.shape[:2]

        # save_path1 = "_____/InitialContours.jpg"
        # save_path2 = "_____/Edges.jpg"
        # cv2.imwrite(save_path1, image_to_draw)
        # cv2.imwrite(save_path2, edges)

        return image_to_draw, contour_image, contours, hierarchy, image_shape
    
    except Exception as e:
        print(f"An error occurred: {e}")
        return None, None, None, None, None
    


def contour_selection(contours, hierarchy, image_shape, contour_image, contour_image_name, top_margin=40, bottom_margin=80, lateral_margin=10):
    try:
        # Validate input types
        if contours is None or not isinstance(contours, list) or not all(isinstance(c, np.ndarray) for c in contours):
            raise TypeError("Contours should be a list of numpy arrays.")
        if hierarchy is None or not isinstance(hierarchy, np.ndarray) or hierarchy.ndim != 3 or hierarchy.shape[2] != 4:
            raise ValueError("Hierarchy must be a 3D numpy array with the shape (1, N, 4).")
        if not isinstance(image_shape, tuple) or len(image_shape) < 2:
            raise TypeError("Image shape should be a tuple with at least two elements (height, width).")
        if not isinstance(top_margin, int) or top_margin < 0:
            raise ValueError("Margin must be a non-negative integer.")
        if not isinstance(bottom_margin, int) or bottom_margin < 0:
            raise ValueError("Margin must be a non-negative integer.")
        
        # Get image dimensions
        height, width= image_shape

        # List to store selected external contours
        selected_contours = []

        # Check number of channels in the contour image and convert if necessary
        if contour_image.ndim == 2:  # Grayscale image
            contour_image = cv2.cvtColor(contour_image, cv2.COLOR_GRAY2BGR)  # Convert to 3 channels (BGR)
        elif contour_image.shape[-1] == 4:  # RGBA image
            contour_image = cv2.cvtColor(contour_image, cv2.COLOR_BGRA2BGR)  # Convert to BGR (3 channels)
        elif contour_image.shape[-1] != 3:  # Invalid number of channels
            raise ValueError(f"Invalid number of channels in the input image: {contour_image.shape[-1]}.")

        # Iterate through each contour and its corresponding hierarchy
        for i, contour in enumerate(contours):
            # Check if the current contour is an external one (parent contour)
            if hierarchy[0][i][3] == -1:
                # Validate contour coordinates using a bounding rectangle
                _, y, _, h = cv2.boundingRect(contour)  # Only y and h are used
                if y >= top_margin and (y + h) <= (height - bottom_margin):

                    # Add the contour to the selected list as it meets all criteria
                    selected_contours.append(contour)

        # Check if any contours were selected
        if not selected_contours:
            print(f"Warning: No external contours passed the selection criteria for image '{contour_image_name}'.")

        # Draw the detected contours on the original image in green color (0, 255, 0)
        image_to_draw = contour_image  # Image is already in BGR format
        cv2.drawContours(image_to_draw, selected_contours, -1, (0, 255, 0), 2)

        # save_path1 = "_____/SelectedContours.jpg"
        # cv2.imwrite(save_path1, image_to_draw)

        return selected_contours, image_to_draw

    except TypeError as te:
        print(f"Type error: {te}")
        return None
    except ValueError as ve:
        print(f"Value error: {ve}")
        return None
    except Exception as e:
        print(f"An unexpected error occurred during contour selection: {e}")
        return None


