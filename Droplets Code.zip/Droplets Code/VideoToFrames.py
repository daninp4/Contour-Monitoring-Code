import cv2
import numpy as np
import matplotlib.pyplot as plt
import operator 
import pyefd
import os
import time
import h5py
import re



#CONVERT VIDEO TO FRAMES
def video_to_frames(path_videos, path_folder):

    try:

        # Verify if the input folder exists
        if not os.path.exists(path_videos):
            raise FileNotFoundError(f"Input folder '{path_videos}' does not exist.")
        
        # Verify if the output folder exists, if not, create it
        if not os.path.exists(path_folder):
            os.makedirs(path_folder)
        
        # Get all video files in the input folder
        video_files = [f for f in os.listdir(path_videos) if f.endswith(('.mp4', '.avi', '.mov', '.mkv'))]
        
        if not video_files:
            return
        
        # Process each video in the folder
        for video_file in video_files:

            try:
                
                video_path = os.path.join(path_videos, video_file)
                
                # Get the base name of the video file (without extension)
                video_name = os.path.splitext(video_file)[0]
                
                # Create a folder for the video (if it doesn't exist)
                video_output_folder = os.path.join(path_folder, video_name)
                
                # Skip the video if the folder already exists (indicating the video has already been processed)
                if os.path.exists(video_output_folder):
                    continue
                
                # Create folders
                os.makedirs(video_output_folder)
                initial_frames_folder = os.path.join(video_output_folder, "Initial Frames")
                os.makedirs(initial_frames_folder)
                processed_frames_folder = os.path.join(video_output_folder, "Processed Frames")
                os.makedirs(processed_frames_folder)
                contour_frames_folder = os.path.join(video_output_folder, "Frames with selected contours")
                os.makedirs(contour_frames_folder)
                time.sleep(0.5)
                
                # Open the video
                cap = cv2.VideoCapture(video_path)
                if not cap.isOpened():
                    raise IOError(f"Error opening video file: {video_path}")
                
                # Get video properties
                fps = cap.get(cv2.CAP_PROP_FPS)
                total_frames = int(cap.get(cv2.CAP_PROP_FRAME_COUNT))
                
                frame_number = 0
                while True:
                    ret, frame = cap.read()
                    if not ret:
                        break  # Exit the loop if no more frames are available
                    
                    # Get the timestamp of the frame in seconds
                    timestamp = frame_number / fps
                    
                    # Name the frame file with frame number and timestamp (in seconds)
                    frame_name = f"{video_name}_frame{frame_number:04d}_time{timestamp:.2f}s.png"
                    frame_path = os.path.join(initial_frames_folder, frame_name)
                    
                    # Save the frame as a PNG image
                    cv2.imwrite(frame_path, frame)
                    
                    frame_number += 1
                
                # Release the video
                cap.release()
            
            except Exception as e:
                continue  # Continue with the next video if an error occurs

        return True
    except Exception as e:
        return False