import cv2
import numpy as np
import matplotlib.pyplot as plt
import operator # for sorting and comparing
import pyefd
import os
import time
import h5py
import re
import subprocess
import shutil



path_videos = '____________/Video_samples'                                        #Complete with the path in which the Video_samples folder is located.
path_folder = '____________/Process'                                              #Complete with the path in which the Process folder is located.
path_h5py = '______________/DataVideos.h5'                                        #Complete with the path in which the HDF5 file is located.
path_video_contours ='_____/Video_contours'                                       #Complete with the path in which the Video_contours folder is located.
path_results = '___________/Results'                                              #Complete with the path in which the Results folder is located.
path_results_h5py = '______/Results/DataVideos.h5'                                #Complete with the path in which the reorganized HDF5 file is located.
path_frames = '____________/Results/Video_X_Contour_FXXXX_X'                      #Complete with the path in which the video for a specific contour is located. The name of the video too.



from VideoToFrames import video_to_frames
from ObtainInfo import create_h5_file_with_groups
from SaveContours import processing, processing_contours, processing_contour_images
from CreateVideos import create_videos_from_frames, create_frames_for_video
from ContourRecognition import process_video_file
from FinalCalculations import save_contour_frames, create_videos_for_specific_contour, get_centroid_trajectory, plot_centroid_points, plot_contours, plot_centroid_and_yx, compute_heading, compute_velocity_acceleration, compute_velocity_comparison, compute_heading_comparison, compute_acceleration_comparison


if __name__ == "__main__":

    video_to_frames(path_videos, path_folder)

    #create_h5_file_with_groups(path_h5py, path_folder)

    #processing(path_folder)

    #processing_contours(path_folder, path_h5py)

    #processing_contour_images(path_folder, path_h5py)

    #create_frames_for_video(path_folder)

    #create_videos_from_frames(path_folder, path_video_contours)

    #process_video_file(path_h5py, path_results)

    #save_contour_frames(path_results_h5py, path_results)

    #create_videos_for_specific_contour(path_frames, path_results)

    #get_centroid_trajectory(path_results_h5py, path_results)

    #plot_centroid_points(path_results_h5py, path_results)

    #plot_contours(path_results_h5py, path_results)

    #plot_centroid_and_yx(path_results_h5py, path_results)

    #compute_heading(path_results_h5py, path_results)

    #compute_velocity_acceleration(path_results_h5py, path_results)

    #compute_velocity_comparison(path_results_h5py, path_results)

    #compute_heading_comparison(path_results_h5py, path_results)

    #compute_acceleration_comparison(path_results_h5py, path_results)



